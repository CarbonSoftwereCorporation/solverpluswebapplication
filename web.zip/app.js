
for (a=1,a<9,a++){
  console.log(a);
}
