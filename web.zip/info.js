var physics="physics "
 document.getElementById("physics").innerHTML=physics;
