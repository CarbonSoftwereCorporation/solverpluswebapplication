  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
</head>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">

    </script>
 

    <link rel="stylesheet" href=
"https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
integrity=
"sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2"crossorigin="anonymous">
<body>
  <style type="text/css">
    
  <center>
    <h2><font color="white">প্রশ্ন করুন</font></h2>
    <br>
    <input type="email"id="email"placeholder="Email address">
    <br>
    <br>
      <textarea id="question" placeholder="Enter your question"rows="30"cols="70">
     Question:
        
      </textarea>
      <br>
      
      <button onclick="massage()"type="submit">Submit</button>
      <a href="massage.html"><button>Cancel</button></a>
    <script src="massage.js"></script>
     <script src=

"https://www.gstatic.com/firebasejs/3.7.4/firebase.js">

    </script>
  </center>

</body>

</html>
